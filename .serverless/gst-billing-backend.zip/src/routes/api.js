const express = require('express');
const authController = require('../controllers/authController');
const adminController = require('../controllers/adminController');
const adminAuthController = require('../controllers/adminAuthController');

const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');

const router = express.Router();

// Auth Routes
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);

// Admin Auth Routes
router.post('/admin/auth/register', adminAuthController.registerAdmin);
router.post('/admin/auth/login', adminAuthController.loginAdmin);

// Admin Routes (Protected + Role Check)
router.get('/admin/pending', authMiddleware, adminMiddleware, adminController.getPendingReviews);
router.post('/admin/approve', authMiddleware, adminMiddleware, adminController.approveUser);
router.post('/admin/approve-business', authMiddleware, adminMiddleware, adminController.approveBusiness);

// Upload Routes
const uploadController = require('../controllers/uploadController');
router.post('/upload', authMiddleware, uploadController.uploadImage);

// Business Routes (Protected)
const businessController = require('../controllers/businessController');
router.post('/business', authMiddleware, businessController.createBusiness);
router.get('/business', authMiddleware, businessController.getMyBusinesses);
router.put('/business/:businessId', authMiddleware, businessController.updateBusiness);

// Party (Buyer/Customer) Routes (Protected)
const partyController = require('../controllers/partyController');
router.post('/parties', authMiddleware, partyController.createParty);
router.get('/parties', authMiddleware, partyController.listParties);
router.get('/parties/:partyId', authMiddleware, partyController.getParty);
router.put('/parties/:partyId', authMiddleware, partyController.updateParty);
router.delete('/parties/:partyId', authMiddleware, partyController.deleteParty);

// Product Routes (Protected)
const productController = require('../controllers/productController');
router.post('/business/:businessId/products', authMiddleware, productController.createProduct);
router.get('/business/:businessId/products', authMiddleware, productController.listProducts);
router.get('/business/:businessId/products/:productId', authMiddleware, productController.getProduct);
router.put('/business/:businessId/products/:productId', authMiddleware, productController.updateProduct);
router.delete('/business/:businessId/products/:productId', authMiddleware, productController.deleteProduct);

// Invoice Routes (Protected)
const invoiceController = require('../controllers/invoiceController');
const invoicePdfController = require('../controllers/invoicePdfController');
router.post('/business/:businessId/invoices', authMiddleware, invoiceController.createInvoice);
router.get('/business/:businessId/invoices', authMiddleware, invoiceController.listInvoices);
router.get('/business/:businessId/invoices/:invoiceId', authMiddleware, invoiceController.getInvoice);
router.put('/business/:businessId/invoices/:invoiceId', authMiddleware, invoiceController.updateInvoice);
router.delete('/business/:businessId/invoices/:invoiceId', authMiddleware, invoiceController.deleteInvoice);
router.post('/business/:businessId/invoices/:invoiceId/pdf', authMiddleware, invoicePdfController.generatePdf);

// Optional: public list of available invoice templates
router.get('/invoice-templates', invoicePdfController.listTemplates);

// Health Check
router.get('/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

module.exports = router;
